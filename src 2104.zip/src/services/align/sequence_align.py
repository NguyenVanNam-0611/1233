from __future__ import annotations

import difflib
from typing import List, Tuple

from src.services.models.block import Block


Opcode = Tuple[str, int, int, int, int]


def _block_similarity(a: Block, b: Block) -> float:
    if a.type != b.type:
        return 0.0

    if a.heading_ctx != b.heading_ctx:
        heading_bonus = 0.15
    else:
        heading_bonus = 0.35

    a_text = (a.signature or "").strip()
    b_text = (b.signature or "").strip()

    text_ratio = difflib.SequenceMatcher(
        a=a_text,
        b=b_text,
        autojunk=False,
    ).ratio()

    return min(1.0, text_ratio + heading_bonus)


def align_blocks(a_blocks: List[Block], b_blocks: List[Block]) -> List[Opcode]:
    a_signatures = []
    b_signatures = []

    for block in a_blocks:
        heading = block.heading_ctx or ""
        a_signatures.append(
            f"{block.type}|{heading}|{block.signature}"
        )

    for block in b_blocks:
        heading = block.heading_ctx or ""
        b_signatures.append(
            f"{block.type}|{heading}|{block.signature}"
        )

    sm = difflib.SequenceMatcher(
        a=a_signatures,
        b=b_signatures,
        autojunk=False,
    )

    raw_opcodes = sm.get_opcodes()
    refined: List[Opcode] = []

    for tag, i1, i2, j1, j2 in raw_opcodes:
        if tag != "replace":
            refined.append((tag, i1, i2, j1, j2))
            continue

        a_slice = a_blocks[i1:i2]
        b_slice = b_blocks[j1:j2]

        if len(a_slice) == 1 and len(b_slice) == 1:
            a_block = a_slice[0]
            b_block = b_slice[0]

            similarity = _block_similarity(a_block, b_block)

            if similarity >= 0.45:
                refined.append(("replace", i1, i2, j1, j2))
            else:
                refined.append(("delete", i1, i2, j1, j1))
                refined.append(("insert", i2, i2, j1, j2))
            continue

        refined.append((tag, i1, i2, j1, j2))

    return refined