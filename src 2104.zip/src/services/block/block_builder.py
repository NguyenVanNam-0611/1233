from __future__ import annotations

import re
from typing import List, Optional

from src.services.models.docnode import DocNode
from src.services.models.block import Block
from src.services.block.signature import signature


# ── Normalize ─────────────────────────────────────────────────────────────────

def _norm(s: str) -> str:
    s = (s or "").lower().strip()
    s = re.sub(r"\s+", " ", s)
    return s

_SKIP_SECTION_PATTERNS = [
    "muc luc",
    "mục lục",
    "table of contents",
    "目次",

    # Skip toàn bộ section lịch sử sửa đổi
    "ly lich sua doi",
    "lý lịch sửa đổi",
    "revision history",
    "change history",
    "document history",
    "改訂履歴",
]

# Cell / paragraph có text khớp → bỏ block đó
_SKIP_BLOCK_PATTERNS = [
    "tiep trang sau",
    "tiếp trang sau",
    "(tiep trang sau)",
    "(tiếp trang sau)",
    "continued on next page",
    "continue on next page",
    "次ページに続く",
]

def _is_skip_section_heading(node: DocNode) -> bool:
    text = _norm(node.content.get("text", ""))
    return any(pat in text for pat in _SKIP_SECTION_PATTERNS)


def _is_skip_block(node: DocNode) -> bool:
    """Bỏ paragraph/heading/table có chứa text cần skip."""
    if node.type in ("paragraph", "heading"):
        text = _norm(node.content.get("text", ""))
        return any(pat in text for pat in _SKIP_BLOCK_PATTERNS)

    if node.type == "table":
        # Bỏ bảng nếu có bất kỳ cell nào chứa text skip
        for n in node.walk():
            if n.type == "cell":
                text = _norm(n.content.get("text", ""))
                if any(pat in text for pat in _SKIP_BLOCK_PATTERNS):
                    return True
    return False


# ── Main builder ──────────────────────────────────────────────────────────────

def build_blocks(doc_root: DocNode) -> List[Block]:
    blocks: List[Block] = []

    current_heading: Optional[str] = None
    current_heading_level: int = 0
    heading_stack: List[dict] = []

    # Khi != None, đang trong vùng skip section (giá trị = level của heading kích hoạt)
    skip_until_level: Optional[int] = None

    for node in doc_root.children:

        # ── Heading ──────────────────────────────────────────────────────────
        if node.type == "heading":
            heading_level = int(node.content.get("level", 1) or 1)

            # Đang skip section: thoát khi gặp heading cùng cấp hoặc cao hơn
            if skip_until_level is not None:
                if heading_level <= skip_until_level:
                    skip_until_level = None  # thoát skip, xử lý heading này bình thường
                else:
                    continue  # vẫn trong section bị skip

            # Heading là "Mục lục" → bắt đầu skip section
            if _is_skip_section_heading(node):
                skip_until_level = heading_level
                continue  # bỏ heading này luôn

            # Heading có text "Tiếp trang sau" → bỏ
            if _is_skip_block(node):
                continue

            # Heading bình thường
            heading_text = (node.content.get("text") or "").strip()

            while heading_stack and heading_stack[-1]["level"] >= heading_level:
                heading_stack.pop()

            heading_stack.append({"text": heading_text, "level": heading_level})

            current_heading = " > ".join(
                x["text"] for x in heading_stack if x["text"]
            )
            current_heading_level = heading_level

            blocks.append(
                Block(
                    type="heading",
                    node=node,
                    signature=signature(node),
                    heading_ctx=current_heading,
                    heading_level=current_heading_level,
                    order=node.order,
                    uid=node.uid,
                )
            )
            continue

        # ── Các block khác ────────────────────────────────────────────────────

        # Đang trong vùng skip section → bỏ tất cả
        if skip_until_level is not None:
            continue

        # Block có text "Tiếp trang sau" → bỏ
        if _is_skip_block(node):
            continue

        blocks.append(
            Block(
                type=node.type,
                node=node,
                signature=signature(node),
                heading_ctx=current_heading,
                heading_level=current_heading_level,
                order=node.order,
                uid=node.uid,
            )
        )

    return sorted(
        blocks,
        key=lambda x: (
            x.order if x.order is not None else 0,
            x.uid or "",
        ),
    )