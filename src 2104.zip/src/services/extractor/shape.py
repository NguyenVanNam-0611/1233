from __future__ import annotations

from typing import List, Optional, Any, Dict
import uuid

from src.services.models.docnode import DocNode
from src.services.utils.hash import image_hash_from_bytes, bytes_to_data_uri, safe_sha256


_NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "wps": "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
    "v": "urn:schemas-microsoft-com:vml",
    "mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
    "pic": "http://schemas.openxmlformats.org/drawingml/2006/picture",
}


def _norm_text(s: str) -> str:
    return " ".join((s or "").replace("\u00a0", " ").split()).strip()


def _emu_to_int(v: Any) -> int:
    try:
        return int(v)
    except Exception:
        return 0


def _next_order(order_ref: Optional[Dict[str, int]]) -> int:
    if order_ref is None:
        return 0
    order_ref["value"] += 1
    return order_ref["value"]


def _extract_images_from_xml(
    xml_elem,
    part,
    uid_prefix: str,
    parent_uid: Optional[str] = None,
    order_ref: Optional[Dict[str, int]] = None,
) -> List[DocNode]:
    nodes: List[DocNode] = []

    blips = xml_elem.xpath(".//a:blip/@r:embed")
    if not blips:
        return nodes

    exts = xml_elem.xpath(".//wp:extent")
    cx = cy = 0
    if exts:
        cx = _emu_to_int(exts[0].get("cx"))
        cy = _emu_to_int(exts[0].get("cy"))

    for i, rid in enumerate(blips, start=1):
        p = part.related_parts.get(rid) if part else None
        if not p:
            continue

        blob = p.blob
        mime = getattr(p, "content_type", None) or "image/png"
        img_uid = f"{uid_prefix}.i{i}"

        nodes.append(
            DocNode(
                type="image",
                uid=img_uid,
                parent_uid=parent_uid,
                order=_next_order(order_ref),
                path=img_uid.replace(".", "/"),
                content={
                    "rid": rid,
                    "hash": image_hash_from_bytes(blob),
                    "sha256": safe_sha256(blob),
                    "mime": mime,
                    "width_emu": cx,
                    "height_emu": cy,
                    "data_uri": bytes_to_data_uri(blob, mime=mime),
                    "image_index": i,
                },
            )
        )

    return nodes


def _parse_p_xml(
    p_xml,
    part,
    uid_prefix: str,
    parent_uid: Optional[str] = None,
    order_ref: Optional[Dict[str, int]] = None,
) -> List[DocNode]:
    text = _norm_text("".join(p_xml.xpath(".//w:t/text()")))

    p_uid = f"{uid_prefix}.p"
    out: List[DocNode] = []

    pnode = DocNode(
        type="paragraph",
        uid=p_uid,
        parent_uid=parent_uid,
        order=_next_order(order_ref),
        path=p_uid.replace(".", "/"),
        content={
            "text": text,
        },
    )
    out.append(pnode)

    imgs = _extract_images_from_xml(
        p_xml,
        part,
        uid_prefix=f"{uid_prefix}.img",
        parent_uid=p_uid,
        order_ref=order_ref,
    )
    out.extend(imgs)

    return [
        n
        for n in out
        if not (
            n.type == "paragraph"
            and not n.content.get("text")
            and len(out) == 1
        )
    ]


def _parse_tbl_xml(
    tbl_xml,
    part,
    uid_prefix: str,
    parent_uid: Optional[str] = None,
    order_ref: Optional[Dict[str, int]] = None,
) -> DocNode:
    rows_xml = tbl_xml.xpath("./w:tr", namespaces=_NS)

    row_count = len(rows_xml)
    col_count = 0

    table_lines: List[str] = []

    for tr in rows_xml:
        tcs = tr.xpath("./w:tc", namespaces=_NS)
        col_count = max(col_count, len(tcs))

        row_text = " | ".join(
            _norm_text("".join(tc.xpath(".//w:t/text()", namespaces=_NS)))
            for tc in tcs
        )
        table_lines.append(row_text)

    table_uid = f"{uid_prefix}.t"

    tnode = DocNode(
        type="table",
        uid=table_uid,
        parent_uid=parent_uid,
        order=_next_order(order_ref),
        path=table_uid.replace(".", "/"),
        content={
            "rows": row_count,
            "cols": col_count,
            "text": "\n".join(table_lines),
        },
    )

    for r_idx, tr in enumerate(rows_xml):
        row_uid = f"{uid_prefix}.r{r_idx}"

        tcs = tr.xpath("./w:tc", namespaces=_NS)

        row_text = " | ".join(
            _norm_text("".join(tc.xpath(".//w:t/text()", namespaces=_NS)))
            for tc in tcs
        )

        rnode = DocNode(
            type="row",
            uid=row_uid,
            parent_uid=table_uid,
            order=_next_order(order_ref),
            path=row_uid.replace(".", "/"),
            content={
                "row_index": r_idx,
                "text": row_text,
            },
        )
        tnode.add_child(rnode)

        for c_idx, tc in enumerate(tcs):
            cell_uid = f"{uid_prefix}.r{r_idx}.c{c_idx}"

            cell_text = _norm_text(
                "".join(tc.xpath(".//w:t/text()", namespaces=_NS))
            )

            cnode = DocNode(
                type="cell",
                uid=cell_uid,
                parent_uid=row_uid,
                order=_next_order(order_ref),
                path=cell_uid.replace(".", "/"),
                content={
                    "row_index": r_idx,
                    "col_index": c_idx,
                    "text": cell_text,
                },
            )
            rnode.add_child(cnode)

            children = []
            child_idx = 0

            for child in tc.iterchildren():
                child_idx += 1

                if child.tag == f"{{{_NS['w']}}}p":
                    children.extend(
                        _parse_p_xml(
                            child,
                            part,
                            uid_prefix=f"{cell_uid}.p{child_idx}",
                            parent_uid=cell_uid,
                            order_ref=order_ref,
                        )
                    )

                elif child.tag == f"{{{_NS['w']}}}tbl":
                    children.append(
                        _parse_tbl_xml(
                            child,
                            part,
                            uid_prefix=f"{cell_uid}.t{child_idx}",
                            parent_uid=cell_uid,
                            order_ref=order_ref,
                        )
                    )

            for ch in children:
                cnode.add_child(ch)

    return tnode


def _parse_txbx_content(
    txbx_xml,
    part,
    uid_prefix: str,
    parent_uid: Optional[str] = None,
    order_ref: Optional[Dict[str, int]] = None,
) -> DocNode:
    sid = str(uuid.uuid4().hex)

    shape = DocNode(
        type="shape",
        uid=uid_prefix,
        parent_uid=parent_uid,
        order=_next_order(order_ref),
        path=uid_prefix.replace(".", "/"),
        content={
            "shape_id": sid,
            "shape_type": "textbox",
        },
    )

    children: List[DocNode] = []

    for idx, child in enumerate(txbx_xml.iterchildren(), start=1):
        child_uid = f"{uid_prefix}.{idx}"

        if child.tag == f"{{{_NS['w']}}}p":
            children.extend(
                _parse_p_xml(
                    child,
                    part,
                    uid_prefix=child_uid,
                    parent_uid=uid_prefix,
                    order_ref=order_ref,
                )
            )

        elif child.tag == f"{{{_NS['w']}}}tbl":
            children.append(
                _parse_tbl_xml(
                    child,
                    part,
                    uid_prefix=child_uid,
                    parent_uid=uid_prefix,
                    order_ref=order_ref,
                )
            )

    p_count = sum(1 for x in children if x.type == "paragraph")
    i_count = sum(1 for x in children if x.type == "image")
    t_count = sum(1 for x in children if x.type == "table")

    shape.content.update(
        {
            "paragraph_count": p_count,
            "image_count": i_count,
            "table_count": t_count,
        }
    )

    for ch in children:
        shape.add_child(ch)

    return shape


def extract_shapes_from_paragraph(
    paragraph,
    uid_prefix: str = "shp",
    parent_uid: Optional[str] = None,
    order_ref: Optional[Dict[str, int]] = None,
) -> List[DocNode]:
    out: List[DocNode] = []
    part = getattr(paragraph, "part", None)

    idx = 0
    for run in paragraph.runs:
        r = run._r
        if r is None:
            continue

        txbxs = r.xpath(".//w:txbxContent")
        for tx in txbxs:
            idx += 1
            out.append(
                _parse_txbx_content(
                    tx,
                    part,
                    uid_prefix=f"{uid_prefix}.{idx}",
                    parent_uid=parent_uid,
                    order_ref=order_ref,
                )
            )

    return out