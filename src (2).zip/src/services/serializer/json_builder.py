from __future__ import annotations

from typing import List, Dict, Any, Optional

from src.services.models.block import Block
from src.services.diff.paragraph_diff import diff_words
from src.services.diff.table_diff import diff_table, analyze_table_change
from src.services.diff.shape_diff import diff_shape
from src.services.diff.image_diff import images_equal, build_image_change


def _section_key(h: Optional[str]) -> str:
    return h if h else "(No heading)"


def _serialize_node(node) -> Optional[Dict[str, Any]]:
    if not node:
        return None

    return {
        "uid": getattr(node, "uid", None),
        "type": getattr(node, "type", None),
        "content": getattr(node, "content", {}) or {},
        "children": [
            _serialize_node(child)
            for child in (getattr(node, "children", []) or [])
        ],
    }


def _serialize_block_side(block: Optional[Block]) -> Optional[Dict[str, Any]]:
    if not block:
        return None

    return {
        "uid": block.uid,
        "type": block.type,
        "order": block.order,
        "heading": block.heading_ctx,
        "preview_text": block.preview_text,
        "node": _serialize_node(block.node),
    }


def _build_context(
    blocks: List[Block],
    index: int,
) -> Dict[str, Optional[Dict[str, Any]]]:
    prev_block = blocks[index - 1] if index - 1 >= 0 else None
    next_block = blocks[index + 1] if index + 1 < len(blocks) else None

    return {
        "previous": _serialize_block_side(prev_block),
        "next": _serialize_block_side(next_block),
    }


def _build_change(
    cid: int,
    change_type: str,
    heading: Optional[str],
    order: int,
    left: Optional[Dict[str, Any]],
    right: Optional[Dict[str, Any]],
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    if left is not None and right is None:
        kind = "delete"
    elif left is None and right is not None:
        kind = "insert"
    else:
        kind = "replace"

    return {
        "id": cid,
        "heading": heading,
        "type": change_type,
        "change_kind": kind,
        "order": order,
        "left": left,
        "right": right,
        **(extra or {}),
    }


def _shape_has_text(block: Block) -> bool:
    """Kiểm tra shape block có paragraph chứa text thực sự không (đệ quy shape lồng nhau)."""
    def _check(node) -> bool:
        for child in (node.children or []):
            if child.type == "paragraph":
                txt = (child.content.get("text") or "").strip()
                if txt:
                    return True
            elif child.type == "shape":
                if _check(child):
                    return True
        return False
    return _check(block.node)

def _shape_has_any_child(block: Block) -> bool:
    """
    Shape decorative thuần túy thường KHÔNG có children (không có txbxContent).
    Shape textbox thật (kể cả rỗng text) vẫn có children (paragraph rỗng / table / shape con).
    """
    node = getattr(block, "node", None)
    children = getattr(node, "children", None) if node is not None else None
    return bool(children)


def _collect_shape_texts(node) -> List[str]:
    """Thu thập tất cả text từ paragraph trong shape, đệ quy. Dùng để build preview."""
    texts = []
    for child in (getattr(node, "children", []) or []):
        if getattr(child, "type", None) == "paragraph":
            txt = (getattr(child, "content", {}) or {}).get("text", "") or ""
            txt = txt.strip()
            if txt:
                texts.append(txt)
        elif getattr(child, "type", None) == "shape":
            texts.extend(_collect_shape_texts(child))
    return texts


def _serialize_shape_block_side(block: Optional[Block]) -> Optional[Dict[str, Any]]:
    """
    Serialize block side cho shape, bổ sung thêm shape_text_lines để
    frontend luôn có text hiển thị ngay cả khi node.children bị rỗng sau serialize.
    """
    if not block:
        return None

    base = _serialize_block_side(block)
    if base is None:
        return None

    # Bổ sung danh sách text lines trực tiếp từ DocNode gốc (trước khi serialize)
    # để frontend không phụ thuộc vào việc parse lại node.children
    base["shape_text_lines"] = _collect_shape_texts(block.node)
    return base


def build_ui_json(
    a_blocks: List[Block],
    b_blocks: List[Block],
    opcodes,
) -> Dict[str, Any]:
    sections_map: Dict[str, Dict[str, Any]] = {}
    flat_changes: List[Dict[str, Any]] = []

    cid = 1

    def add_change(change: Dict[str, Any]):
        nonlocal cid

        heading = _section_key(change.get("heading"))
        if heading not in sections_map:
            sections_map[heading] = {
                "heading": heading,
                "changes": [],
            }

        sections_map[heading]["changes"].append(change)
        flat_changes.append(change)

    for tag, i1, i2, j1, j2 in opcodes:
        if tag == "equal":
            continue

        # ── INSERT ────────────────────────────────────────────────────────────
        if tag == "insert":
            for j in range(j1, j2):
                b = b_blocks[j]

               # Chỉ bỏ qua shape decorative (không có child). Textbox rỗng vẫn giữ lại.
                if b.type == "shape" and (not _shape_has_text(b)) and (not _shape_has_any_child(b)):
                    continue

                add_change(
                    _build_change(
                        cid=cid,
                        change_type=f"{b.type}_inserted",
                        heading=b.heading_ctx,
                        order=b.order,
                        left=None,
                        right=_serialize_shape_block_side(b) if b.type == "shape" else _serialize_block_side(b),
                        extra={
                            "left_context": None,
                            "right_context": _build_context(b_blocks, j),
                        },
                    )
                )
                cid += 1

        # ── DELETE ────────────────────────────────────────────────────────────
        elif tag == "delete":
            for i in range(i1, i2):
                a = a_blocks[i]

                # Chỉ bỏ qua shape decorative (không có child). Textbox rỗng vẫn giữ lại.
                if a.type == "shape" and (not _shape_has_text(a)) and (not _shape_has_any_child(a)):
                    continue

                add_change(
                    _build_change(
                        cid=cid,
                        change_type=f"{a.type}_deleted",
                        heading=a.heading_ctx,
                        order=a.order,
                        left=_serialize_shape_block_side(a) if a.type == "shape" else _serialize_block_side(a),
                        right=None,
                        extra={
                            "left_context": _build_context(a_blocks, i),
                            "right_context": None,
                        },
                    )
                )
                cid += 1

        # ── REPLACE ───────────────────────────────────────────────────────────
        elif tag == "replace":
            pairs = min(i2 - i1, j2 - j1)

            for k in range(pairs):
                ai = i1 + k
                bj = j1 + k

                a = a_blocks[ai]
                b = b_blocks[bj]

                # FIX: ưu tiên a.heading_ctx vì file A là nguồn gốc.
                # Khi shape B bị xóa hết text, b.heading_ctx có thể là None
                # khiến 2 shape ở 2 heading khác nhau bị gom chung vào 1 section.
                heading = a.heading_ctx or b.heading_ctx
                order = min(a.order, b.order)

                # ── Paragraph ────────────────────────────────────────────────
                if a.type == "paragraph" and b.type == "paragraph":
                    old_text = a.node.content.get("text", "") or ""
                    new_text = b.node.content.get("text", "") or ""

                    if old_text != new_text:
                        add_change(
                            _build_change(
                                cid=cid,
                                change_type="paragraph_modified",
                                heading=heading,
                                order=order,
                                left=_serialize_block_side(a),
                                right=_serialize_block_side(b),
                                extra={
                                    "word_diff": diff_words(old_text, new_text),
                                    "left_context": _build_context(a_blocks, ai),
                                    "right_context": _build_context(b_blocks, bj),
                                },
                            )
                        )
                        cid += 1
                    continue

                # ── Table ─────────────────────────────────────────────────────
                if a.type == "table" and b.type == "table":
                    table_changes = diff_table(a.node, b.node)

                    if table_changes:
                        table_analysis = analyze_table_change(
                            a_tbl=a.node,
                            b_tbl=b.node,
                            table_changes=table_changes,
                        )

                        add_change(
                            _build_change(
                                cid=cid,
                                change_type="table_modified",
                                heading=heading,
                                order=order,
                                left=_serialize_block_side(a),
                                right=_serialize_block_side(b),
                                extra={
                                    "table_changes": table_changes,
                                    "table_analysis": table_analysis,
                                    "left_context": _build_context(a_blocks, ai),
                                    "right_context": _build_context(b_blocks, bj),
                                },
                            )
                        )
                        cid += 1
                    continue

                # ── Shape ─────────────────────────────────────────────────────
                if a.type == "shape" and b.type == "shape":
                    a_has_text = _shape_has_text(a)
                    b_has_text = _shape_has_text(b)

                    # Cả 2 đều rỗng → bỏ qua hoàn toàn
                    if not a_has_text and not b_has_text:
                        continue

                    # a có text, b rỗng (text bị xóa hết)
                    # → emit shape_modified với change_kind=replace để frontend
                    #   biết shape VẪN CÒN nhưng nội dung đã bị xóa hết
                    if a_has_text and not b_has_text:
                        add_change(
                            _build_change(
                                cid=cid,
                                change_type="shape_modified",
                                heading=heading,
                                order=order,
                                left=_serialize_shape_block_side(a),
                                right=_serialize_shape_block_side(b),
                                extra={
                                    "shape_cleared": True,   # ← flag để frontend biết
                                    "shape_changes": [],
                                    "left_context": _build_context(a_blocks, ai),
                                    "right_context": _build_context(b_blocks, bj),
                                },
                            )
                        )
                        cid += 1
                        continue

                    # a rỗng, b có text (shape mới được điền nội dung)
                    if not a_has_text and b_has_text:
                        add_change(
                            _build_change(
                                cid=cid,
                                change_type="shape_modified",
                                heading=heading,
                                order=order,
                                left=_serialize_shape_block_side(a),
                                right=_serialize_shape_block_side(b),
                                extra={
                                    "shape_changes": [],
                                    "left_context": _build_context(a_blocks, ai),
                                    "right_context": _build_context(b_blocks, bj),
                                },
                            )
                        )
                        cid += 1
                        continue

                    # Cả 2 đều có text → diff bình thường
                    shape_changes = diff_shape(a.node, b.node)
                    if shape_changes:
                        add_change(
                            _build_change(
                                cid=cid,
                                change_type="shape_modified",
                                heading=heading,
                                order=order,
                                left=_serialize_shape_block_side(a),
                                right=_serialize_shape_block_side(b),
                                extra={
                                    "shape_changes": shape_changes,
                                    "left_context": _build_context(a_blocks, ai),
                                    "right_context": _build_context(b_blocks, bj),
                                },
                            )
                        )
                        cid += 1
                    continue

                # ── Image ─────────────────────────────────────────────────────
                if a.type == "image" and b.type == "image":
                    if not images_equal(a.node, b.node):
                        add_change(
                            _build_change(
                                cid=cid,
                                change_type="image_modified",
                                heading=heading,
                                order=order,
                                left=_serialize_block_side(a),
                                right=_serialize_block_side(b),
                                extra={
                                    "image_change": build_image_change(a.node, b.node),
                                    "left_context": _build_context(a_blocks, ai),
                                    "right_context": _build_context(b_blocks, bj),
                                },
                            )
                        )
                        cid += 1
                    continue

                # ── Type mismatch ─────────────────────────────────────────────
                add_change(
                    _build_change(
                        cid=cid,
                        change_type=f"{a.type}_to_{b.type}_modified",
                        heading=heading,
                        order=order,
                        left=_serialize_block_side(a),
                        right=_serialize_block_side(b),
                        extra={
                            "left_context": _build_context(a_blocks, ai),
                            "right_context": _build_context(b_blocks, bj),
                        },
                    )
                )
                cid += 1

            # Phần dư bên a → deleted
            for i in range(i1 + pairs, i2):
                a = a_blocks[i]

                # Bỏ qua shape không có text
                if a.type == "shape" and not _shape_has_text(a):
                    continue

                extra_data: Dict[str, Any] = {
                    "left_context": _build_context(a_blocks, i),
                    "right_context": None,
                }
                if a.type == "table":
                    table_analysis = analyze_table_change(
                        a_tbl=a.node,
                        b_tbl=None,
                        table_changes=[],
                    )
                    extra_data["table_analysis"] = table_analysis

                add_change(
                    _build_change(
                        cid=cid,
                        change_type=f"{a.type}_deleted",
                        heading=a.heading_ctx,
                        order=a.order,
                        left=_serialize_shape_block_side(a) if a.type == "shape" else _serialize_block_side(a),
                        right=None,
                        extra=extra_data,
                    )
                )
                cid += 1

            # Phần dư bên b → inserted
            for j in range(j1 + pairs, j2):
                b = b_blocks[j]

                # Bỏ qua shape không có text
                if b.type == "shape" and not _shape_has_text(b):
                    continue

                add_change(
                    _build_change(
                        cid=cid,
                        change_type=f"{b.type}_inserted",
                        heading=b.heading_ctx,
                        order=b.order,
                        left=None,
                        right=_serialize_shape_block_side(b) if b.type == "shape" else _serialize_block_side(b),
                        extra={
                            "left_context": None,
                            "right_context": _build_context(b_blocks, j),
                        },
                    )
                )
                cid += 1

    ordered_sections = sorted(
        sections_map.values(),
        key=lambda x: min(
            (c.get("order", 0) for c in x["changes"]),
            default=0,
        ),
    )

    for section in ordered_sections:
        section["changes"] = sorted(
            section["changes"],
            key=lambda x: (x.get("order", 0), x.get("id", 0)),
        )

    return {
        "sections": ordered_sections,
        "changes": sorted(
            flat_changes,
            key=lambda x: (x.get("order", 0), x.get("id", 0)),
        ),
    }